package edu.uml;

/**
 * Factory class for creating StockService instances
 * Note that this is using the Factory Pattern and not 
 * a static factory!
 *
 */
public class StockServiceFactory {

	/**
	 * Returns an instance of a StockService
	 * 
     * @return a <CODE>StockService</CODE> instance
     */
	public static StockService getStockService() {
		return new BasicStockService();
	}
	
}
