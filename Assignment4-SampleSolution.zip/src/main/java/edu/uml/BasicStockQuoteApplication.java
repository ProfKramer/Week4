package edu.uml;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

/**
 * A simple application that shows the StockService in action.
 */
public class BasicStockQuoteApplication {

	/**
	 * Run the StockTicker application. When invoking the program supply one stock
	 * ticker symbol or one stock ticker symbol and a start and end date
	 *
	 * @param stock ticker symbol - required
	 * @param start date - optional
	 * @param end   date - optional
	 * 
	 * I added a little error checking but it's not required
	 * 
	 */
	public static void main(String[] args) {

		StockService stockService = StockServiceFactory.getStockService();
		;

		if ((args.length != 1) && (args.length != 3)) {
			// bad number of arguments, exiting
			System.out.println("Wrong number of arguments");
			System.exit(0);
		} else {
			if (args.length == 1) {
				// get today's quote
				String symbol = args[0];
				StockQuote currentValue = stockService.getQuote(symbol);
				System.out.printf("%s %6.2f \n", currentValue.getTickerSymbol(), currentValue.getValue().doubleValue());
			} else if (args.length == 3) {
				// get history
				try {
					// Use this date format - all dates must be entered as 'MM/dd/yyyy'
					SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");					
					// Store the ticker symbol
					String symbol = args[0];
					
					// Convert input string for start date to a Calendar object
					Calendar startDate = Calendar.getInstance();
					startDate.setTime(dateFormat.parse(args[1]));
					
					// Convert the input string end date to a Calendar object
					Calendar endDate = Calendar.getInstance();
					endDate.setTime(dateFormat.parse(args[2]));
					
					// Retrieve stock history
					List<StockQuote> history = stockService.getQuote(symbol, startDate, endDate);

					for (StockQuote singleDay : history) {
						System.out.printf("%s %s %6.2f \n", singleDay.getTickerSymbol(), 
								singleDay.getDate().getTime(), singleDay.getValue());
					}
				} catch (ParseException exp) {
					System.out.println("Error parsing input arguments");
				}
			}
		}
	}
}
