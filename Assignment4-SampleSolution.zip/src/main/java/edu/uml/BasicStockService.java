package edu.uml;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.SortedSet;

public class BasicStockService implements StockService {

	/**
	 * No-arg constructor
	 * 
	 */
	protected BasicStockService() {
	}

	/**
	 * Return the current price for a share of stock for the given symbol
	 * 
	 * @param tickerSymbol the stock symbol of the company you want a quote for.
	 *                     e.g. APPL for APPLE
	 *
	 * @return a <CODE>StockQuote </CODE> instance
	 */
	public StockQuote getQuote(String tickerSymbol) {
		return new StockQuote(450.23, "APPL", Calendar.getInstance());
	}

	public List<StockQuote> getQuote(String symbol, Calendar startDate, Calendar endDate) {

		// I'm calling a private helper method to create some StockQuote objects in order to keep the 
		// getQuote method uncluttered. When I have a real data source, I won't need the helper method.		
		List<StockQuote> tmpObjects = createObjects();
		
		// Create an empty list to store the results in
		List<StockQuote> stockHistory = new ArrayList<>();
		
		// Return just the StockQuote objects that fall between the start and end dates
		for (StockQuote quote : tmpObjects) {
			if ((quote.getDate().getTimeInMillis() > startDate.getTimeInMillis()) && 
					(quote.getDate().getTimeInMillis() > startDate.getTimeInMillis()))	{
				stockHistory.add(quote);
			}
		}
		return stockHistory;
	}
	
	/**
	 * Temporary private helper method to create a stock history
	 * 
	 * @return List<StockQuote>
	 */
	private List<StockQuote> createObjects() {
		List<StockQuote> stockHistory = new ArrayList<>();
		int year=2020;
		int month = 0;
		int day = 15;
		double price = 100.34;
		for (int i=0; i<12; i++) {
			Calendar date = new GregorianCalendar(year, month, day);
			stockHistory.add(new StockQuote(price, "APPL", date));
			month++;
			price = price + 50/1+2;
		}
		return stockHistory;
	}

}
