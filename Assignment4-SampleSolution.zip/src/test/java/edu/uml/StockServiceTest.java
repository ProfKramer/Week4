package edu.uml;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

import edu.uml.BasicStockService;
import edu.uml.StockQuote;
import edu.uml.StockService;
import edu.uml.StockServiceFactory;

public class StockServiceTest {
    
	String symbol;
	Calendar startDate;
	Calendar endDate;
	
	@Before
	public void setup() {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		startDate = Calendar.getInstance();
		try {
			startDate.setTime(dateFormat.parse("06/10/2020"));
			endDate = Calendar.getInstance();
			endDate.setTime(dateFormat.parse("12/10/2020"));
			symbol = "APPL";
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void singleStockTickerTest() {
		StockService sampleStockService = StockServiceFactory.getStockService();
		assertTrue("getStockService returned a BasicStockService", sampleStockService instanceof BasicStockService);
		assertEquals("Check ticker price", sampleStockService.getQuote("APPL").getValue(),
				new BigDecimal(450.23000000000001818989403545856475830078125));

	}

	@Test
	public void stockTickerHistoryTest() {
		StockService sampleStockService = StockServiceFactory.getStockService();
		assertTrue("getStockService returned a BasicStockService", sampleStockService instanceof BasicStockService);
		List<StockQuote> staticList = sampleStockService.getQuote(symbol, startDate, endDate);
		assertTrue("Check number of quotes returned", (staticList.size() == 7));		

	}
	
	@Test
	public void mainAppTest() {
		StockService sampleStockService = StockServiceFactory.getStockService();
		assertTrue("getStockService returned a BasicStockService", sampleStockService instanceof BasicStockService);
		List<StockQuote> staticList = sampleStockService.getQuote(symbol, startDate, endDate);
		assertTrue("Check number of quotes returned", (staticList.size() == 7));		

	}
    
   
}